<?php 

include_once 'form.php';

?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>Google Recaptcha</title>
    <link rel="stylesheet" type="text/css" href="./styles.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
    <h1>Google reCAPTHA Demo</h1>


    <?php if(!empty($statusMsg)){ ?>
        <p class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></p>
    <?php } ?>

    <form action="" method="post">

        <div class="input-group">
            <input type="text" name="name" value="chandra" placeholder="Your name" required="" />
        </div>
         <div class="input-group">
            <input type="email" name="email" value="chandra.bhushan.think@gmail.com" placeholder="Your name" required="" />
        </div>
        <div class="input-group">
            <textarea name="message" placeholder="Type message..." required=""></textarea>
        </div>
        
        <!-- Google reCAPTCHA box -->
        <div class="g-recaptcha" data-sitekey="6LeD22EhAAAAABHEaLS_UETS_xs90Ti-cm1sCdEQ"></div>

        <!-- Submit button -->
        <input type="submit" name="submit" value="SUBMIT">
    </form>

    <script>
       // when form is submit
       $('#comment_form').submit(function() {
        // we stoped it
        event.preventDefault();
        var email = $('#email').val();
        var comment = $("#comment").val();
        // needs for recaptacha ready
        grecaptcha.ready(function() {
            // do request for recaptcha token
            // response is promise with passed token
            grecaptcha.execute('6LeD22EhAAAAABHEaLS_UETS_xs90Ti-cm1sCdEQ', {action: 'create_comment'}).then(function(token) {

                alert(token);
                // add token to form
                $('#comment_form').prepend('<input type="hidden" name="g-recaptcha-response" value="' + token + '">');
                $.post("form.php",{email: email, comment: comment, token: token}, function(result) {
                    console.log(result);
                    if(result.success) {
                        alert('Thanks for posting comment.')
                    } else {
                        alert('You are spammer ! Get the @$%K out.')
                    }
                });
            });;
        });
    });
</script>
</body>
</html>